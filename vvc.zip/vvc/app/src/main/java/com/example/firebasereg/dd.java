package com.example.firebasereg;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.firebasereg.application.WavAudioRecorder;
import com.example.firebasereg.network.NetworkService;
import com.firebase.client.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import omrecorder.AudioChunk;
import omrecorder.AudioRecordConfig;
import omrecorder.OmRecorder;
import omrecorder.PullTransport;
import omrecorder.PullableSource;
import omrecorder.Recorder;

public  class dd extends Activity implements TheInterface {

    Button bb;
    NetworkService service;
    private Object JsonToken;
    String ids = "";


    String speakerId;


    private TextView txtRecordLabel, txtStatus;
    TextView edname;

    private WavAudioRecorder mRecorder;
    private static final String mRcordFilePath = Environment.getExternalStorageDirectory() + "/testwavecall4.wav";
    String IdentifyNAMe;
    private int requestCode = 0;
    private boolean audioRecorded = false;
    private byte[] bytes;
    private String mostRecentOp;
    private int color;
    private Firebase mRootRef, mRootRef2;
    DatabaseReference mDatabase, mDatabase2;
    Firebase mRef;
    ListView mlistview;
    ArrayList<String> mArray = new ArrayList<>();
    Button btnEnrollment, btnIdentification, Recorder2;
    Recorder recorder;
    public  String _AudioSavePathInDevice = null;

    String IDNAME="Wait...";
    Context context;
    String idMatched ;


    public class firebase extends Application {
        @Override
        public void onCreate() {
            super.onCreate();
            //  current = super.getApplicationContext();
            Firebase.setAndroidContext(this);
        }
    }
    DatabaseReference database1;
    FirebaseDatabase database=FirebaseDatabase.getInstance();

    final void logVal(String val) {

    }
    @Override
    public void theMethod(String result) {

        try {
            ids="";
            JSONArray jsonarray = new JSONArray(result);
            for (int i = 0; i < jsonarray.length(); i++) {

                JSONObject jsonobject = null;
                jsonobject = jsonarray.getJSONObject(i);
                if (jsonobject.getString("enrollmentStatus").equals("Enrolled")) {
                    ids += jsonobject.getString("identificationProfileId");
                    if (i < (jsonarray.length() - 1)) {
                        ids += ",";
                    }
                }

            }
            if(ids.endsWith(","))
                ids=ids.substring(0,ids.length()-1);

            Log.w("IDS==>",ids);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void theMethod2(String result) {
//            JSONArray jsonarray = new JSONArray(result);
        if (result != "no") {
            Log.w("_", "=================================================================================================");
            DatabaseReference mRef=database.getReference("profileID").child(result);
            if (mRef!=null){
                mRef = mRef.child("name");
                mRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String value=dataSnapshot.getValue(String.class);
                        if (value != null) {
                        //    Log.w("name",value);
                            //IDNAME=value;
                            edname.setText(value);




                        }
                        else {
                            // Log.w("name","not found");
                            IDNAME="not found";
                            edname.setText("try again");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
            }
            else {
                // Log.w("mRef","notFouned");
            }
           Log.w("aaa", result);
          //idMatched =  getVoiceName(result);

            Log.w("ids", "=================================================================================================");

        }
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {

            requestWindowFeature(Window.FEATURE_NO_TITLE);
            this.setFinishOnTouchOutside(false);
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_dd);
            initializeContent();

            new IdentificationHelper(dd.this).execute();
            Firebase.setAndroidContext(this);
            mRef = new Firebase("https://regeister-5dae6.firebaseio.com/AllProfils");
            String out = "";
            Recorder2 =(Button) findViewById(R.id.c) ;
            edname.setText("press record");
            Recorder2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setupRecorder();

                    recorder.startRecording();
                    edname.setText("recording.......");

                    new Handler().postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            try {
                                recorder.pauseRecording();
                                recorder.stopRecording();
                                edname.setText("press Identify");

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    },10000);



                }
            });
            btnIdentification = (Button) findViewById(R.id.b);
            btnIdentification.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(View v) {




                    new IdentificationRequest(dd.this, ids).execute();

                    edname.setText("wait....");






                    audioRecorded = false;
                    // IdentifyNAMe   =   getIntent().getExtras().getString("IDESSNAMEE");
                    //  edname.setText(""+IdentifyNAMe+"");

                }





            });

        }
        catch (Exception e)
        {
            Log.d("Exception", e.toString());
            e.printStackTrace();
        }
       /* bb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {










        });*/
    }

    private void initializeContent() {
        //bb = (Button) findViewById(R.id.b);

        edname =(TextView) findViewById(R.id.tv);

    }
    private void setupRecorder() {
        recorder = OmRecorder.wav(
                new PullTransport.Default(mic(), new PullTransport.OnAudioChunkPulledListener() {
                    @Override
                    public void onAudioChunkPulled(AudioChunk audioChunk) {
                    }
                }), file());
    }

    private PullableSource mic() {
        return new PullableSource.Default(
                new AudioRecordConfig.Default(
                        MediaRecorder.AudioSource.MIC, AudioFormat.ENCODING_PCM_16BIT,
                        AudioFormat.CHANNEL_IN_MONO, 16000
                )
        );
    }

    @NonNull
    private File file() {

        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(),   "testwavecall4.wav");
        _AudioSavePathInDevice = file.getPath();
        return file;
    }

    public String getAudioPath() {
        return _AudioSavePathInDevice;
    }


}
