package com.example.firebasereg;
import android.content.Context;
import android.content.SharedPreferences;

public class Save {
    public static void save(Context ctx, String name, String value){
        SharedPreferences a= ctx.getSharedPreferences("aa", Context.MODE_PRIVATE);
        SharedPreferences.Editor edt=a.edit();
        edt.putString(name, value);
        edt.apply();
    }
    public static String read(Context ctx , String name, String dafultvalue){
        SharedPreferences a= ctx.getSharedPreferences("aa", Context.MODE_PRIVATE);
        return a.getString(name, dafultvalue);
    }
}

