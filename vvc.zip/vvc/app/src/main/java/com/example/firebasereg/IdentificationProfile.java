package com.example.firebasereg;

public class IdentificationProfile {
    public String identificationProfileId;
}
