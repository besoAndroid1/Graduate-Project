package com.example.firebasereg;

public class ProfilesIDs {
    public String ProfilesIDs;


}
