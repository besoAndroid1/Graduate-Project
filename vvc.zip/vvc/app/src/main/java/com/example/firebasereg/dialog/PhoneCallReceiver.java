package com.example.firebasereg.dialog;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.firebase.client.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Date;

public abstract class PhoneCallReceiver extends BroadcastReceiver
{

    public class firebase extends Application {
        @Override
        public void onCreate() {
            super.onCreate();
            //  current = super.getApplicationContext();
            Firebase.setAndroidContext(context);
        }
    }
    private static int lastState = TelephonyManager.CALL_STATE_IDLE;
    private static Date callStartTime;
    private static boolean isIncoming;
    private static String savedNumber;
    String Number;
    public static String vall;
    public String vall2;
    String number;
    Context context;
    FirebaseDatabase database;

    @Override
    public void onReceive(final Context context, Intent intent)
    {

        final FirebaseDatabase database=FirebaseDatabase.getInstance();
        try {
            if (intent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {
                savedNumber = intent.getExtras().getString("android.intent.extra.PHONE_NUMBER");
            } else {
                final String stateStr = intent.getExtras().getString(TelephonyManager.EXTRA_STATE);
                number = intent.getExtras().getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
                Number = number;

                DatabaseReference mRef = database.getReference("users").child(Number);
                if (mRef != null) {
                    mRef = mRef.child("name");
                    mRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            String value = dataSnapshot.getValue(String.class);
                            vall = value;
                            number = value;

                            if (value != null) {
                                // found = true;
                                Toast.makeText(context, "name: " + value + "", Toast.LENGTH_LONG).show();
                                //    found =true;
                                Log.w("caling u ", vall);
                                vall2 = vall;


                                int state = 0;
                                if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                                    state = TelephonyManager.CALL_STATE_IDLE;
                                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                                    state = TelephonyManager.CALL_STATE_OFFHOOK;
                                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                                    state = TelephonyManager.CALL_STATE_RINGING;


                                    onCallStateChanged(context, state, PhoneCallReceiver.vall, PhoneCallReceiver.vall);

                                }
                            }
                            else {
                                DatabaseReference mRef = database.getReference("contacts").child(Number);
                                if (mRef != null) {
                                    mRef = mRef.child("contactName");
                                    mRef.addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            String value = dataSnapshot.getValue(String.class);
                                            vall = value;
                                            number = value;

                                            if (value != null) {
                                                // found = true;
                                                Toast.makeText(context, "name: " + value + "", Toast.LENGTH_LONG).show();
                                                //    found =true;
                                                Log.w("caling u ", vall);
                                                value= vall;


                                                int state = 0;
                                                if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                                                    state = TelephonyManager.CALL_STATE_IDLE;
                                                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                                                    state = TelephonyManager.CALL_STATE_OFFHOOK;
                                                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                                                    state = TelephonyManager.CALL_STATE_RINGING;
                                                }
                                                onCallStateChanged(context, state, PhoneCallReceiver.vall, PhoneCallReceiver.vall);

                                                //    Toast.makeText(context, "unknown number", Toast.LENGTH_LONG).show();


                                                //found = false;


                                            } else {
                                                int state = 0;
                                                if (stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE)) {
                                                    state = TelephonyManager.CALL_STATE_IDLE;
                                                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)) {
                                                    state = TelephonyManager.CALL_STATE_OFFHOOK;
                                                } else if (stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                                                    state = TelephonyManager.CALL_STATE_RINGING;
                                                }
                                                onCallStateChanged(context, state, null, PhoneCallReceiver.vall);

                                            }

                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                        }
                                    });



                                }




//
//                int state = 0;
//                if(stateStr.equals(TelephonyManager.EXTRA_STATE_IDLE))
//                {
//                    state = TelephonyManager.CALL_STATE_IDLE;
//                }
//                else if(stateStr.equals(TelephonyManager.EXTRA_STATE_OFFHOOK))
//                {
//                    state = TelephonyManager.CALL_STATE_OFFHOOK;
//                }
//                else if(stateStr.equals(TelephonyManager.EXTRA_STATE_RINGING))
//                {
//                    state = TelephonyManager.CALL_STATE_RINGING;
//                }
//
//                onCallStateChanged(context, state, this.number, PhoneCallReceiver.vall);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }


            }
        }


        catch (Exception e)
        {
            e.printStackTrace();
        }
    }




//      protected void onIncomingCallStarted(Context ctx, String vall, Date start, String Cname){
////          context =   ctx;
////          final Intent intent = new Intent(context, MyCustomDialog.class);
////          intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////          intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
////          intent.putExtra("phone_no",PhoneCallReceiver.vall);
////          new Handler().postDelayed(new Runnable()
////          {
////              @Override
////              public void run()
////              {
////                  context.startActivity(intent);
////              }
////          },2000);
////
////        MyCustomDialog dialog   =   new MyCustomDialog(ctx);
////        dialog.show();
//
//      }


    protected void onIncomingCallStarted(Context ctx, String pnumber, Date start, String Cname)
    {
        Toast.makeText(ctx,"Jeet Incoming Call from "+ pnumber,Toast.LENGTH_LONG).show();

        context =   ctx;

        final Intent intent = new Intent(context, dialog2.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("phone_no",pnumber);


                context.startActivity(intent);
            }


//        MyCus/*tomDialog dialog   =   new MyCustomDialog(context);
//        dialog.*/show();







    protected void onIncomingCallEnded(Context ctx, String vall, Date start, Date end){}

    public void onCallStateChanged(final Context context, int state, String number, String nameC)
    {
        try {
            Log.w("TEST ",number);

            if(lastState == state)
            {

                return;
            }
            switch (state)
            {
                case TelephonyManager.CALL_STATE_RINGING:
                    isIncoming = true;
                    callStartTime = new Date();
                    savedNumber = vall;
                    onIncomingCallStarted(context, this.number, callStartTime, nameC);

                    break;

                case TelephonyManager.CALL_STATE_OFFHOOK:
                    if (isIncoming)
                    {
                        onIncomingCallEnded(context,savedNumber,callStartTime,new Date());
                        final Intent intent = new Intent(context, MyCustomDialog.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        //intent.putExtra("phone_no",pnumber);

                                context.startActivity(intent);

                    }


                case TelephonyManager.CALL_STATE_IDLE:
                    if(isIncoming)
                    {
                        onIncomingCallEnded(context, savedNumber, callStartTime, new Date());
                    }
            }
            lastState = state;
        } catch (NullPointerException e) {
            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING:
                    isIncoming = true;
                    callStartTime = new Date();
                    savedNumber = vall;
                    Toast.makeText(context, "Unknown", Toast.LENGTH_LONG).show();
                    final Intent intent = new Intent(context, dialog2.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    intent.putExtra("phone_no", "Unkown Number");
                    context.startActivity(intent);
                    break;

                case TelephonyManager.CALL_STATE_OFFHOOK:
                    if (isIncoming)
                    {
                        onIncomingCallEnded(context,savedNumber,callStartTime,new Date());
                        final Intent intent1 = new Intent(context, MyCustomDialog.class);
                        intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent1.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        //intent.putExtra("phone_no",pnumber);

                        context.startActivity(intent1);

                    }


                case TelephonyManager.CALL_STATE_IDLE:

            }


            }

    }
}
