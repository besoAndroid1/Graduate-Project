package com.example.firebasereg.Home;

import android.app.TabActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.Toast;

import com.example.firebasereg.Activity.VerificationActivity;
import com.example.firebasereg.R;
import com.example.firebasereg.Save;

public class Taphost extends TabActivity {
    Boolean session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TabHost mTabHost=getTabHost();
        mTabHost.addTab(mTabHost.newTabSpec("main").setIndicator("Contact").
                setContent(new Intent(this, Contacts.class)));
        mTabHost.addTab(mTabHost.newTabSpec("main").setIndicator("History").
                setContent(new Intent(this,History.class)));
        mTabHost.setCurrentTab(0);
        SESSION();

    }
    private void SESSION() {
        session= Boolean.valueOf(Save.read(getApplicationContext(),"session", "false"));
        if (!session){
            Intent verify=new Intent(getApplicationContext(), VerificationActivity.class);
            startActivity(verify);
            finish();
        }else {


        }
    }
    @Override
    public void onBackPressed(){
        super.onBackPressed();

        finish();
    }


}

