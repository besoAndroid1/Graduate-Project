package com.example.firebasereg.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.media.AudioFormat;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.firebasereg.Home.Taphost;
import com.example.firebasereg.IdProfileData;
import com.example.firebasereg.IdentificationProfile;
import com.example.firebasereg.R;
import com.example.firebasereg.Save;
import com.example.firebasereg.application.ApplicationController;
import com.example.firebasereg.application.WavAudioRecorder;
import com.example.firebasereg.network.NetworkCall;
import com.example.firebasereg.network.NetworkService;
import com.example.firebasereg.progress;
import com.firebase.client.Firebase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.gson.Gson;

import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okhttp3.internal.http2.ErrorCode;
import omrecorder.AudioChunk;
import omrecorder.AudioRecordConfig;
import omrecorder.OmRecorder;
import omrecorder.PullTransport;
import omrecorder.PullableSource;
import omrecorder.Recorder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RecordAudio extends AppCompatActivity {
    NetworkService service;
    private Object JsonToken;
    String speakerId,PassPnum;
    private Button btnRecord, btnProfile, btnEnroll;
    private TextView txtRecordLabel, txtStatus;
    EditText edname ;
    private WavAudioRecorder mRecorder;
    private static final String mRcordFilePath = Environment.getExternalStorageDirectory() + "/testwave3.wav";
    private int requestCode = 0;
    private boolean audioRecorded = false;
    private byte[] bytes;
    private String mostRecentOp;
    private int color ;
    private Firebase mRootRef,mRootRef2;
    DatabaseReference mDatabase,mDatabase2;
    Firebase mRef;

    private Button btnrecord,btnfinish;
    final String[] result = {null};
    private TextView tv_recordlabel;
    private EditText edage;

    private static final String LOG_TAG = "AudioRecordTest";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    Recorder recorder;
    public  String _AudioSavePathInDevice = null;
    private StorageReference mStorageRef;
    private ProgressDialog mProgress;
    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Firebase.setAndroidContext(this);

        mRootRef2 = new Firebase("https://console.firebase.google.com/project/regeister-5dae6/database/regeister-5dae6/data/");
        mDatabase = FirebaseDatabase.getInstance().getReference().child("AllProfils");
        mDatabase2 = FirebaseDatabase.getInstance().getReference().child("profileID");
        mRecorder = WavAudioRecorder.getInstanse();
        txtStatus = (TextView) findViewById(R.id.txtStatus);
        txtStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        service = ApplicationController.getInstance().getNetworkService();
        IdProfileData data = new IdProfileData("en-US");
        Call<IdentificationProfile> createProfile = service.createProfile(data);
        createProfile.enqueue(new Callback<IdentificationProfile>() {
            @Override
            public void onResponse(Call<IdentificationProfile> call, Response<IdentificationProfile> response) {
                if (response.isSuccessful()) {
                    // Response
                    speakerId = response.body().identificationProfileId;

                    txtStatus.setText(response.body().identificationProfileId);
                    Log.w("Id", speakerId);

                } else {
                    //Response
                    //Log.i("yunju-profile", response.errorBody().string());
                    try {
                        result[0] = response.errorBody().string();
                        Log.w("AAAAA", String.valueOf(result));
                        Gson gson = new Gson();
                        ErrorCode errorCode = gson.fromJson(result[0], ErrorCode.class);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    txtStatus.setText(result[0]);
                    Log.w("Id", String.valueOf(result));

                }
            }

            @Override
            public void onFailure(Call<IdentificationProfile> call, Throwable t) {

                Log.i("yunju-profile", t.toString());
                Log.i("yunju-profile", t.getMessage());
                txtStatus.setText("failed - onFailure");
            }
        });
        btnrecord = (Button) findViewById(R.id.btnrecord);
        btnfinish = (Button) findViewById(R.id.btn_Finish);
        edname = (EditText) findViewById(R.id.ed_name);
        tv_recordlabel = (TextView) findViewById(R.id.tv_recordlabel);
        edage = (EditText) findViewById(R.id.ed_age);
        Firebase.setAndroidContext(this);
        mRootRef = new Firebase("https://regeister-5dae6.firebaseio.com/users");
        mStorageRef = FirebaseStorage.getInstance().getReference();
        mProgress = new ProgressDialog(this);

        btnfinish.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {

                                             String age = edage.getText().toString();
                                             String name = edname.getText().toString();
                                             //     startRegister();
                                             if (TextUtils.isEmpty(name) ) {
                                                 edname.setError("Invalid Name");

                                             } else if (TextUtils.isEmpty(age)){
                                                 edage.setError("Invalid Age");
                                             }

                                             else {
                                                 creatFirebase();

                                                 createnrolment();
                                                 Save.save(getApplicationContext(), "session", "true");
                                                 Intent done = new Intent(getApplicationContext(), Taphost.class);
                                                 startActivity(done);


                                                 try {
                                                     bytes = FileUtils.readFileToByteArray(new File(mRcordFilePath));
                                                 } catch (
                                                         Exception e) {
                                                     Log.e("yunju-enrollment", "Failed reading file : " + e.toString());
                                                 }

                                                 RequestBody requestBody = RequestBody.create(MediaType.parse("application/octet-stream"), bytes);
                                                 Call<ResponseBody> call = service.enroll(speakerId, true, requestBody);
                                                 try {
                                                     retrofit2.Response<ResponseBody> r = new NetworkCall().execute(call).get();
                                                     Log.e("TEST", "CODE:" + String.valueOf(r.code()));
                                                     if (r.code() != 202) {
                                                         Toast.makeText(getBaseContext(), r.errorBody().string(), Toast.LENGTH_SHORT).show();
                                                     } else {
                                                         Toast.makeText(getBaseContext(), "You are enrolled.", Toast.LENGTH_SHORT).show();
                                                         mostRecentOp = r.headers().get("Operation-Location").split("/")[r.headers().get("Operation-Location").split("/").length - 1];
                                                         Toast.makeText(getBaseContext(), mostRecentOp, Toast.LENGTH_SHORT).show();
                                                     }
                                                 } catch (
                                                         Exception e) {
                                                     Log.e("TEST", "Failed to execute request : " + e.toString());
                                                 }


                                                 audioRecorded = false;
                                             }
                                         }
        });
        btnrecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setupRecorder();

                recorder.startRecording();
                Toast.makeText(getBaseContext(), "start recording for 20 sec", Toast.LENGTH_LONG).show();

                new Handler().postDelayed(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        try {
                            recorder.pauseRecording();
                            recorder.stopRecording();
                            Toast.makeText(getBaseContext(), "stop recording ", Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                },20000);
            }

        });



    }

    private void creatFirebase() {
        String name=edname.getText().toString();
        Firebase childref =mRootRef.child("name");
        childref.push().setValue(name);
        String age=edage.getText().toString();
        Firebase creff=mRootRef.child("age");
        creff.push().setValue(age);
        Toast.makeText(RecordAudio.this,"Regiester is done ",Toast.LENGTH_LONG).show();
        Intent intent=new Intent(RecordAudio.this, Taphost.class);
        startActivity(intent);

    }

    private void createnrolment() {
        String Id = txtStatus.getText().toString();
        Firebase childref1 = mRootRef2.child("ID");
        childref1.setValue(Id);
        DatabaseReference curent_user_db = mDatabase2.child(Id);
        curent_user_db.child("ID").setValue(Id);
        String name = edname.getText().toString();
        Firebase childref2 = mRootRef2.child("name");
        childref2.setValue(name);
        DatabaseReference curent_user_db2 = mDatabase2.child(Id);
        curent_user_db2.child("name").setValue(name);

        //  DatabaseReference curent_user_db2 = mDatabase2.child(Id);
        // curent_user_db2.child("name").setValue(name);

    }
  /* private void uploadAudio() {
        mProgress.setMessage("Audio is upload...");
        mProgress.show();
        StorageReference filepath=mStorageRef.child("Audio").child("new_audio.mp3");
        Uri uri = Uri.fromFile(new File(fileName));
        filepath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                mProgress.dismiss();
               tv_recordlabel.setText("upload finish");


            }
        });



    }*/


    private void setupRecorder() {
        recorder = OmRecorder.wav(
                new PullTransport.Default(mic(), new PullTransport.OnAudioChunkPulledListener() {
                    @Override
                    public void onAudioChunkPulled(AudioChunk audioChunk) {
                    }
                }), file());
    }

    private PullableSource mic() {
        return new PullableSource.Default(
                new AudioRecordConfig.Default(
                        MediaRecorder.AudioSource.MIC, AudioFormat.ENCODING_PCM_16BIT,
                        AudioFormat.CHANNEL_IN_MONO, 16000
                )
        );
    }

    @NonNull
    public File file() {

        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(),   "/testwave3.wav");
        _AudioSavePathInDevice = file.getPath();
        return file;
    }

    public String getAudioPath() {
        return _AudioSavePathInDevice;
    }



}
