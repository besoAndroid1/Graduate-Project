package com.example.firebasereg.dialog;

import android.content.Context;

public class CallReceiver extends PhoneCallReceiver
{
    Context context;

//
//    @Override
//    protected void onIncomingCallStarted(Context ctx, String pnumber, Date start, String Cname)
//    {
//        Toast.makeText(ctx,"Jeet Incoming Call from "+ Cname,Toast.LENGTH_LONG).show();
//
//        context =   ctx;
//
//        final Intent intent = new Intent(context, MyCustomDialog.class);
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//        intent.putExtra("phone_no",Cname);
//
//        new Handler().postDelayed(new Runnable()
//        {
//            @Override
//            public void run()
//            {
//                context.startActivity(intent);
//            }
//        },2000);
//
////        MyCus/*tomDialog dialog   =   new MyCustomDialog(context);
////        dialog.*/show();
//    }
//
//    @Override
//    protected void onIncomingCallEnded(Context ctx, String pnumber, Date start, Date end)
//    {
//        Toast.makeText(ctx,"Call dropped"+ pnumber,Toast.LENGTH_LONG).show();
//    }
}
