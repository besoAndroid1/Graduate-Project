package com.example.firebasereg;

import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.util.Log;

import com.firebase.client.Firebase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import okhttp3.*;
import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;


public class IdentificationRequest  extends AsyncTask<Void, Void, String> {
    String IDNAME;
    Context context;


    public class firebase extends Application {
        @Override
        public void onCreate() {
            super.onCreate();
            //  current = super.getApplicationContext();
            Firebase.setAndroidContext(this);
        }
    }
    DatabaseReference database1;
    FirebaseDatabase database=FirebaseDatabase.getInstance();

    private byte[] bytes;
    private static final String mRcordFilePath = Environment.getExternalStorageDirectory() + "/testwavecall4.wav";
    public String ids = "";
    TheInterface listener;
    public IdentificationRequest (Context context, String id)
    {
        this.ids = id;//"4a643856-61f7-4395-823d-80139283b2fd,671cf3a2-3e22-48fe-aaf1-afa437288459,5101d729-2f5e-4d71-be77-4112d1e7ceb1";//"899c7d92-a9c1-4164-bc30-53ed6a22cd2e,762bdf68-811d-4c32-8fd3-910d06f8db9c,6a04ff58-3b97-42f1-9177-c56f93999bc5,4e36c5f1-e66b-479f-8821-0dea7004e30a";
        Log.w("===================", id);
        listener = (TheInterface) context;

    }

//    public String removeLast(String str) {
//        if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == ',') {
//            str = str.substring(0, str.length() - 1);
//        }
//        return str;
//    }
    @Override
    protected String doInBackground(Void... voids) {
        Log.w("7a", "========================================");

        try {
            bytes = FileUtils.readFileToByteArray(new File(mRcordFilePath));
        } catch (Exception e) {
            Log.e("yunju-enrollment", "Failed reading file : " + e.toString());
        }
        String result = "";
        String[] idsList = ids.split(",");
        if(idsList.length <=10) {
          result = SendIdentificationRequest(this.ids);
            Log.w("======",result );
          //getVoiceName(result,context);


        }
        else
        {
            int counter = 0;
            int count = idsList.length;

            while(count > 10)
            {
                this.ids = "";
                for(int i = counter;i<counter+10;i++)
                {
                    this.ids+=idsList[i];
                    if(i<(counter+10)-1)
                        this.ids+=",";
                }
                counter +=10;
                count-=10;
                result=  SendIdentificationRequest(this.ids);
              if(result.length()>0&&!result.equals("00000000-0000-0000-0000-000000000000"))
                  break;
            }
            if(result.length()==0&& count > 0)
            {
                this.ids = "";
                for(int i = 0;i<count;i++)
                {
                    this.ids+=idsList[i];
                    if(i<count-1)
                        this.ids+=",";
                }
                result= SendIdentificationRequest(this.ids);
            }


           // getVoiceName(result,context);

            // if result == empty or 00000-000000-000000-000000
        }
        return null;
    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
    }
    private void getVoiceName(String result, final Context context){
        DatabaseReference mRef=database.getReference("profileID").child(result);
        if (mRef!=null){
            mRef = mRef.child("name");
            mRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String value=dataSnapshot.getValue(String.class);
                    if (value != null) {
                        Log.w("name",value);
                        IDNAME=value;



                    }
                    else {
                        Log.w("name","not found");
                        IDNAME="not found";
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }
        else {
            Log.w("mRef","notFouned");
        }

       // final Intent intent = new Intent(context, dd.class);
        //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        //intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
      //  intent.putExtra("IDESSNAMEE",IDNAME);


    }




    private String GetReponseResult(String operationLocation)
    {
        String ProfileId = "";
        try{
        OkHttpClient client2 = new OkHttpClient();
        Request request2 = new Request.Builder()
                .url(operationLocation)
                .get()
                .addHeader("ocp-apim-subscription-key", "4d1c1b43853845f4914de5bbbb5252f0")
                .build();
        try {
            Thread.sleep(5000);

            Response response2 = client2.newCall(request2).execute();

            String resultJsonResponse = response2.body().string();

            Log.w("7a", "=================================================================================================");
            Log.w("aaa", resultJsonResponse);
            Log.w("7a", "=================================================================================================");


            Log.w("7a", "========================================");
            try {
                JSONObject jsonObject = new JSONObject(resultJsonResponse);
                String status = jsonObject.getString("status");
                switch (status) {
                    case "failed":
                        Log.w("failed", "Please try Again after 3 seconds");
                        listener.theMethod2("no");
                        break;
                    case "running":
                        GetReponseResult(operationLocation);
                        break;
                    case "notstarted":
                        Log.w("failed", "Please check your internet connection");
                        listener.theMethod2("no");
                        break;
                    case "succeeded":
                        JSONObject resultObj = jsonObject.getJSONObject("processingResult");
                        String confidence = resultObj.getString("confidence");
                        if (confidence == "Low") {
                            listener.theMethod2("no");

                        } else {
                            listener.theMethod2(resultObj.getString("identifiedProfileId"));
                            ProfileId =resultObj.getString("identifiedProfileId") ;
                        }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
        return ProfileId;
    }
    private String SendIdentificationRequest(String ids)
    {
        final String[] MatchedProfileId = {""};
        OkHttpClient client = new OkHttpClient();

        MediaType mediaType = MediaType.parse("application/octet-stream");
        RequestBody body = RequestBody.create(MediaType.parse("application/octet-stream"), bytes);

        Request request = new Request.Builder()
                .url("https://westus.api.cognitive.microsoft.com/spid/v1.0/identify?identificationProfileIds=" + ids + "&shortAudio=true")
                .post(body)
                .addHeader("ocp-apim-subscription-key", "4d1c1b43853845f4914de5bbbb5252f0")
                .addHeader("content-type", "audio/wave")
                .build();
           client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.w("7a", "Request failure");
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    final String header = response.header("Operation-Location");
                    MatchedProfileId[0] = GetReponseResult(header);
                    Log.w("7a", header);
                }
            });


        return MatchedProfileId[0];
    }


}
