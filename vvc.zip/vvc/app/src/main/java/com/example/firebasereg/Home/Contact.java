package com.example.firebasereg.Home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.example.firebasereg.Activity.RecordAudio;

public class Contact  {
    private String ContactName;
    private String ContactNumber;


    public String getContactName() {
        return ContactName;

    }

    public void setContactName(String contactName) {
        ContactName = contactName;
    }

    public String getContactNumber() {
        return ContactNumber;
    }

    public void setContactNumber(String contactNumber) {
        ContactNumber = contactNumber;
    }}
