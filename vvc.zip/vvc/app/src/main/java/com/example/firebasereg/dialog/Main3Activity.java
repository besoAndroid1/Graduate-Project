package com.example.firebasereg.dialog;

import android.app.Activity;

public class Main3Activity extends Activity {
}
